﻿using femotor.Models;

namespace femotor.ViewModel
{
    public class MotorDetailViewModel
    {
        public Motor motor  { get; set; }
        //public IEnumerable<Review> ReviewList { get; set; }

        
    }
}
